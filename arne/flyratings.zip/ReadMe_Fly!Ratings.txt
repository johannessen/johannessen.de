Fly!Ratings 1.1 development release 
for Flyscripts! by Anthony Merton

(c) 2001 Arne Johannessen
with help from Simeon Schuerer
mailto:ajohannessen@mac.com
Freeware!  :-)


WARNING: This is an early alpha release and has not been
thoroughly tested. Use it at your own risk!!


Get marks for the landings you Fly!


System requirements:
This script runs on any Mac or PC running Fly! with Flyscripts! 1.2.1
by Anthony Merton. I think some older versions of Flyscripts can be
used as well, but I've only tested it with 1.2.1 on a Mac.


Troubleshooting:
If you've got problems using this script, make sure that
1) Flyscripts! is installed (perhaps try using version 1.2.1),
2) flyscripts.dll is inside your Modules:Mac: or Modules\PC\ folder,
3) FlyRatings.fsc is inside your Flyscripts! folder,
4) you've activated Flyscripts! (usually ALT F12).
If your problem can't be solved by these tips, send me email or post
your question at AVSIMs General Fly! Forum. The URL is:
http://www.avsim.com/cgi-bin/dcforum/dcboard.cgi?az=list&forum=DCForumID4
(If you're german speaking, you might prefer the Fly! forum at
www.flightxpress.de )


Enjoy! :-)

Arne
